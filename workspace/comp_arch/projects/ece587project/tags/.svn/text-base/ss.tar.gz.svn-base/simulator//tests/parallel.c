
main()
{
	int i, j;
	int a[10][10];
	int temp1 = 0, sum = 0;

	for (i = 0; i < 10; i++) {
		for (j = 0; j < 10; j++) {
			a[i][j] = i*i + j*j;
		}
	}

	for (i = 0; i < 10; i++) {
		temp1 = 0;
		for (j = 0; j < 10; j++) {
			temp1 += a[i][j];
		}
		sum += temp1;
	}

	printf("\n%d\n\n", sum);
}

