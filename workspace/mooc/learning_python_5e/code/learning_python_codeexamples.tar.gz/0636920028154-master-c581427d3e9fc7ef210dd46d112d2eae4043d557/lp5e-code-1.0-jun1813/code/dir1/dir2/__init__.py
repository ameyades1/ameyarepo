print('dir2 init')
y = 2
