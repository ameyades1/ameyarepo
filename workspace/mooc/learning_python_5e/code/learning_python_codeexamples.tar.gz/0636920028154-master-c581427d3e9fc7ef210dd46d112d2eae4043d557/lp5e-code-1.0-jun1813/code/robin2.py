#!python2
print 'Run', 'away more!...'      # 2.x statement