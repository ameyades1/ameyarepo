import nested1                    # Get module as a whole
nested1.X = 88                    # OK: change nested1's X
nested1.printer()
