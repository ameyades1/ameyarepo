print('hello world')
print(2 ** 100)
