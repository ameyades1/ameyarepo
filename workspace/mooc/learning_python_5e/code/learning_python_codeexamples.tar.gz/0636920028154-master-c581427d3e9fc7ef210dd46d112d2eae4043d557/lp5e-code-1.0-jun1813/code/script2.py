import sys
print(sys.path)
x = 2
print(x ** 32)
