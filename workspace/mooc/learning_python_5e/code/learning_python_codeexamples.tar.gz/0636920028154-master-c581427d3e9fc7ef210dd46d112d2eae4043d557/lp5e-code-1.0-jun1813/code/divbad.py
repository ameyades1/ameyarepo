X = 0
print(1 / X)
